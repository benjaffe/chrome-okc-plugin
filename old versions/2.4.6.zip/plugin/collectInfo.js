if () {
	$('#messages li .subject').map(function(){
	  return $(this).text();
	}).get()
}