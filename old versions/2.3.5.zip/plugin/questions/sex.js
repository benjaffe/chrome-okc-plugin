_OKCP.fileQuestions.sex =
	{
		"cuddling": [
			{
				"qid":"48753",
				"text":"Do you like to cuddle?",
				"answerText": ["Yes.", "No.", "Sometimes - It depends."],
				"score": [1, -1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid":"19378",
				"text":"How are you most likely to show your partner you care?",
				"answerText": ["Words: Tell them how much you appreciate them", "Actions: Do something nice (like a date or errand)", "Gifts: Buy them flowers, jewelery or a new gadget", "Touch: Give them a hug, massage or kiss"],
				"score": [0, 0, 0, 1],
				"weight": [0, 0, 0, 1]
			},
			{
				"qid":"72318",
				"text":"Would you consider inviting someone to bed with you for clearly-stated non-sexual purposes (e.g., cuddle and sleep only) on a first date?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"41850",
				"text":"How important is it for you to make physical contact when showing affection for someone?",
				"answerText": ["Very important.", "Somewhat important.", "Not important."],
				"score": [1, 0, -1],
				"weight": [1, 1, 1]
			}
		],

		"love_over_sex": [
			{
				"qid":"35",
				"text":"Regardless of future plans, what's more interesting to you right now?",
				"answerText": ["Sex", "Love"],
				"score": [-1, 1],
				"weight": [1, 1]
			},
			{
				"qid":"14913",
				"text":"Did you join OkCupid just so you could find people to have sex with?",
				"answerText": ["Yes", "No"],
				"score": [-1, 1],
				"weight": [1, 0.5]
			},
			{
				"qid":"41953",
				"text":"About how long do you want your next relationship to last?",
				"answerText": ["One night", "A few months to a year", "Several years", "The rest of my life"],
				"score": [-1, 0.3, 0.6, 1],
				"weight": [1, 0.5, 0.8, 1]
			},
			{
				"qid":"20135",
				"text":"How do you feel about falling in love?",
				"answerText": ["I love it and want it very much", "I try to avoid it", "I like to just let it happen", "I'm indifferent / not sure"],
				"score": [1, -1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			}
		],

		"group_sex": [
			{
				"qid":"32",
				"text":"Group sex (with 3 or more people):",
				"answerText": ["I have tried it.", "It seriously interests me.", "I have little or no interest."],
				"score": [1, 1, -1],
				"weight": [1, 1, 1]
			}
		],

		"fetish": [
			{
				"qid":"67511",
				"text":"Suppose you\'re dating someone who seems to have long-term potential. You discover that they want to urinate on you during sex. Would you consider staying with this person?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.2]
			},
			{
				"qid":"665",
				"text":"Are you fetish-friendly?",
				"answerText": ["Bring out the toys!", "Never tried it, but I'm open-minded.", "Not sure/don't know what they really are.", "Ew!"],
				"score": [1, 1, 0, -1],
				"weight": [1, 1, 1, 1]
			}
		],

		"rough_kinky": [
			{
				"qid":"18530",
				"text":"Do you want your partner to be kinkier than you?",
				"answerText": ["Yes", "No", "Not possible"],
				"score": [1, -1, 1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"1028",
				"text":"Is your ideal sex rough or gentle?",
				"answerText": ["Rough", "Gentle", "I enjoy both equally", "I'm a virgin"],
				"score": [1, -1, 1, -1],
				"weight": [1, 0.5, 1, 1]
			},
			{
				"qid":"72086",
				"text":"If your partner needed lovemaking to always be gentle, would you be fine with this?",
				"answerText": ["Yes.", "No."],
				"score": [-1, 1],
				"weight": [1, 1]
			},
			{
				"qid":"9628",
				"text":"Biting?",
				"answerText": ["No", "Yes", "Let's break skin"],
				"score": [-1, 0.5, 1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"30115",
				"text":"Have you ever gotten, or would you ever get, a piercing below the belt?",
				"answerText": ["I have.", "I would.", "I wouldn't."],
				"score": [1, 1, -1],
				"weight": [1, 1, 0.4]
			},
			{
				"qid":"1133",
				"text":"Do you have rape fantasies?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [1, 0.2]
			},
			{
				"qid":"58812",
				"text":"Would you consider roleplaying out a rape fantasy with partner who asked you to?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.3]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			}
		],


		"BDSM": [
			{
				"qid":"20",
				"text":"BDSM: Without looking it up, do you know exactly what it stands for?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			}
		],

		"masochistic": [
			{
				"qid":"30",
				"text":"Would you like to receive pain during sex?",
				"answerText": ["Yes, lots and lots", "Yes, some", "No"],
				"score": [1, 0.3, -1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"28545",
				"text":"When having sex, do you like to have your hair pulled?",
				"answerText": ["Yes, and hard!", "Yes, but gently.", "No way.", "Don't know / Not sure."],
				"score": [1, 0.3, -1, 0],
				"weight": [1, 1, 1, 0.5]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			}
		],

		"dominant": [
			{
				"qid":"61733",
				"text":"Would you be pleased if a partner expressed the desire to be sexually humiliated by you?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
				
			},
			{
				"qid":"463",
				"text":"In your ideal sexual encounter, do you take control, or do they?",
				"answerText": ["I take control", "They take control"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"83808",
				"text":"Would you ever consider a relationship where you would take on an exclusive sexual role as master or slave?",
				"answerText": ["Yes, as the master only.", "Yes, as the slave only.", "Yes, as the master or the slave.", "No."],
				"score": [1, -1, 1, -1],
				"weight": [1, 1, 0.7, 1]
			}
		],
		

		"submissive": [
			{
				"qid":"463",
				"text":"In your ideal sexual encounter, do you take control, or do they?",
				"answerText": ["I take control", "They take control"],
				"score": [-1, 1],
				"weight": [1, 1]
			},
			{
				"qid":"60726",
				"text":"If a trusted partner asked you to submit to them sexually, would you? Assume that this would involve letting them collar you, command you, and have control over you during sex.",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.5]
			},
			{
				"qid":"38320",
				"text":"Is it generally acceptable to you for a sex partner to initiate foreplay while you are sleeping?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"83808",
				"text":"Would you ever consider a relationship where you would take on an exclusive sexual role as master or slave?",
				"answerText": ["Yes, as the master only.", "Yes, as the slave only.", "Yes, as the master or the slave.", "No."],
				"score": [-1, 1, 1, -1],
				"weight": [1, 1, 0.7, 1]
			},
			{
				"qid":"79635",
				"text":"How would you feel if someone called you \"good girl\" or \"good boy\" during sex?",
				"answerText": ["Positive.", "Negative.", "Indifferent.", "It would depend on which of the two I was called."],
				"score": [1, -1, 0, 1],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid":"11",
				"text":"How does the idea of being slapped hard in the face during sex make you feel?",
				"answerText": ["Horrified", "Aroused", "Nostalgic", "Indifferent"],
				"score": [-1, 1, 1, 0],
				"weight": [1, 1, 0.7, 0.6]
			},
			{
				"qid":"84005",
				"text":"As an adult, have you ever worn a leash and collar in public?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.2]
			},
			{
				"qid":"48347",
				"text":"Do you think you could ever enjoy being humiliated as part of a sexual experience?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.6]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			}
		],



		"bondage": [
			{
				"qid":"29",
				"text":"Would you rather...",
				"answerText": ["be tied up during sex", "do the tying", "avoid bondage all together"],
				"score": [1, 1, -1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"1134",
				"text":"Do you have a desire (even if it's secret) to take part in sexual activities involving bondage?",
				"answerText": ["Yes", "No", "Absolutely not."],
				"score": [1, 0, -1],
				"weight": [1, 0.5, 1]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			}
		],


		"anal": [
			{
				"qid":"1040",
				"text":"Receiving anal sex?",
				"answerText": ["I like it / I think I might like it", "I don't like it / I don't think I would like it"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"18600",
				"text":"People who like RECEIVING anal sex are...",
				"answerText": ["Exploring their sexuality to the full", "Perverts", "Beyond my comprehension"],
				"score": [1, -1, -1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"64476",
				"text":"Under the right circumstances, would you allow a partner to lick your anus?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			}
		],

		"shaven": [
			{
				"qid":"58829",
				"text":"When it comes to your pubic hair, do you make a regular effort to maintain its appearance (or lack thereof)?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			}
		],

		"unshaven": [
			{
				"qid":"58829",
				"text":"When it comes to your pubic hair, do you make a regular effort to maintain its appearance (or lack thereof)?",
				"answerText": ["Yes.", "No."],
				"score": [-1, 1],
				"weight": [0.5, 1]
			}
		]

	};