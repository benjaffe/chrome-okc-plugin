_OKCP.fileQuestions.sex =
	{
		"cuddling": [
			{
				"qid":"48753",
				"text":"Do you like to cuddle?",
				"answerText": ["Yes.", "No.", "Sometimes - It depends."],
				"score": [1, -1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid":"19378",
				"text":"How are you most likely to show your partner you care?",
				"answerText": ["Words: Tell them how much you appreciate them", "Actions: Do something nice (like a date or errand)", "Gifts: Buy them flowers, jewelery or a new gadget", "Touch: Give them a hug, massage or kiss"],
				"score": [0, 0, 0, 1],
				"weight": [0, 0, 0, 1]
			},
			{
				"qid":"72318",
				"text":"Would you consider inviting someone to bed with you for clearly-stated non-sexual purposes (e.g., cuddle and sleep only) on a first date?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"41850",
				"text":"How important is it for you to make physical contact when showing affection for someone?",
				"answerText": ["Very important.", "Somewhat important.", "Not important."],
				"score": [1, 0, -1],
				"weight": [1, 1, 1]
			}
		],

		"love_over_sex": [
			{
				"qid":"35",
				"text":"Regardless of future plans, what's more interesting to you right now?",
				"answerText": ["Sex", "Love"],
				"score": [-1, 1],
				"weight": [1, 1]
			},
			{
				"qid":"14913",
				"text":"Did you join OkCupid just so you could find people to have sex with?",
				"answerText": ["Yes", "No"],
				"score": [-1, 1],
				"weight": [1, 0.5]
			},
			{
				"qid":"41953",
				"text":"About how long do you want your next relationship to last?",
				"answerText": ["One night", "A few months to a year", "Several years", "The rest of my life"],
				"score": [-1, 0.3, 0.6, 1],
				"weight": [1, 0.5, 0.8, 1]
			},
			{
				"qid":"20135",
				"text":"How do you feel about falling in love?",
				"answerText": ["I love it and want it very much", "I try to avoid it", "I like to just let it happen", "I'm indifferent / not sure"],
				"score": [1, -1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "21",
				"text": "Do you enjoy meaningless sex?",
				"answerText": ["Yes", "No"],
				"score": [-1, 1]
			}
		],

		"casual_sex": [
			{
				"qid":"35",
				"text":"Regardless of future plans, what's more interesting to you right now?",
				"answerText": ["Sex", "Love"],
				"score": [1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"14913",
				"text":"Did you join OkCupid just so you could find people to have sex with?",
				"answerText": ["Yes", "No"],
				"score": [1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"41953",
				"text":"About how long do you want your next relationship to last?",
				"answerText": ["One night", "A few months to a year", "Several years", "The rest of my life"],
				"score": [1, 0, 0, 0],
				"weight": [1, 0, 0, 0]
			},
			{
				"qid": "21",
				"text": "Do you enjoy meaningless sex?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [1, 0.5]
			}
		],

		"group_sex": [
			{
				"qid":"32",
				"text":"Group sex (with 3 or more people):",
				"answerText": ["I have tried it.", "It seriously interests me.", "I have little or no interest."],
				"score": [1, 1, -1],
				"weight": [1, 1, 1]
			}
		],

		"fetish": [
			{
				"qid":"67511",
				"text":"Suppose you\'re dating someone who seems to have long-term potential. You discover that they want to urinate on you during sex. Would you consider staying with this person?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.2]
			},
			{
				"qid":"665",
				"text":"Are you fetish-friendly?",
				"answerText": ["Bring out the toys!", "Never tried it, but I'm open-minded.", "Not sure/don't know what they really are.", "Ew!"],
				"score": [1, 1, 0, -1],
				"weight": [1, 1, 1, 1]
			},
			{//Added by RAA
				"qid":"40441",
				"text":"If you were to die, would whoever goes through your personal belongings be shocked by what they find?",
				"answerText": ["Yes.", "No.", "Maybe a little bit."],
				"score": [1, -1, 0],
				"weight": [0.5, 0.2, 0.2,]
			},
			{//Added by RAA
				"qid":"61958",
				"text":"Imagine you become involved in a relationship with a someone who has a specific sexual fetish, without which they cannot be satisfied. If the fetish is harmless, but does nothing for you, how enthusiastic would you be about it?",
				"answerText": ["Very enthusiastic.", "Somewhat enthusiastic.", "Not at all enthusiastic."],
				"score": [1, 1, -1],
				"weight": [1, 1, 1,]
			},
			{//Added by RAA
				"qid":"26469",
				"text":"Have you ever tasted your own sexual fluids?",
				"answerText": ["Yes", "No, and I would never", "No, but I would"],
				"score": [1, -1, 0],
				"weight": [1, 1, 0]
			},
			// { // Added by RAA
			//	"qid":"38423",
			//	"text":"What do you usually wear when you sleep?",
			//	"answerText": ["Pajamas.", "Underwear.", "Nothing.", "Something else."],
			//	"score": [-1, 0, 1, 0],
			//	"weight": [1, 1, 1, 1]
			// },
			{ // Added by RAA
				"qid":"61823",
				"text":"As long as you both agreed that nobody else would ever see the video, would you let a partner film the two of you having sex?",
				"answerText": ["Yes.", "No.", "Maybe, depending upon the partner."],
				"score": [1, -1, 0],
				"weight": [1, 1, 1]
			},
			{ // Added by RAA
				"qid":"29384",
				"text":"Would you allow your partner to kiss you after performing oral sex on you?",
				"answerText": ["Allow? I enjoy it.", "Yes.", "No.", "It depends."],
				"score": [1, 1, -1, 0],
				"weight": [1, 1, 1, 1]
			},
			{ // Added by RAA
				"qid":"49652",
				"text":"What do you think of voyeurism?",
				"answerText": ["It turns me on.", "It turns me off.", "It is perverted.", "I don't care."],
				"score": [1, -1, -1, 0],
				"weight": [1, 1, 1, 1]
			},
			{ // Added by RAA
				"qid":"71994",
				"text":"What do you consider kinky",
				"answerText": ["Whip Cream", "Lube", "Handcuffs", "Floggers"],
				"score": [0, -1, 1, 1],
				"weight": [1, 1, 1, 1]
			},
			{ // Added by RAA
				"qid":"77669",
				"text":"I am kinky and proud of it.",
				"answerText": ["Damn straight", "Well, I'm kinky, but not exactly proud", "Ewwww, kinky! Give me more missionary sex please.", "Huh?"],
				"score": [1,1,-1,0],
				"weight": [1, 1, 1, 1]
			},
			{ // Added by RAA
				"qid":"74018",
				"text":"How do you feel about fisting? Fisting is where one inserts their entire hand into their partner's vagina (or anus).",
				"answerText": ["I think it's disgusting / impossible", "I simply don't find it interesting", "I'd try it, but I'll need some practice first", "I already enjoy it / really want to try it"],
				"score": [-1,0,1,1],
				"weight": [1, 1, 1, 1]
			},
			{ // Added by RAA
				"qid":"124568",
				"text":"How far, sexually, are you willing to go with someone you've been dating for only a short time?",
				"answerText": ["Not far at all, I'd keep it simple.", "I might try something new, just nothing kinky.", "I might trying something kinky", "Teach me something new! I'll do anything!"],
				"score": [-1,0,1,1],
				"weight": [1, 1, 1, 1]
			},
			{ // Added by RAA
				"qid":"35355",
				"text":"How open are you to trying new things in bed?",
				"answerText": ["Very open. I'll try anything once.", "I'm open, but I don't get too crazy.", "Hesitant, but it might happen.", "Not at all."],
				"score": [1, 1, -1, -1],
				"weight": [1, .5, .5, 1]
			},
			{ // Added by RAA
				"qid":"26",
				"text":"Have you ever owned sex toys?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{ // Added by RAA
				"qid":"57731",
				"text":"Would you consider dating someone who is much kinkier than you are?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.5]
			},
			{ // Added by RAA
				"qid":"1408",
				"text":"Would you wear your partner's underclothing if they wanted you to?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{ // Added by RAA
				"qid":"54517",
				"text":"Are you sexually attracted to any inanimate objects?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.3]
			},
			{ // Added by RAA
				"qid":"30169",
				"text":"Do you enjoy giving oral sex?",
				"answerText": ["Love it!", "It's okay.","Not so much.","Gross!"],
				"score": [1,1,0,-1],
				"weight": [1,1,1,1]
			},
			{ // Added by RAA
				"qid":"9462",
				"text":"Are tears arousing?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.2, 0.1]
			},
			// { // Added by RAA
			//	"qid":"85318",
			//	"text":"Do you have any deep dark fantasies that you would not share with anyone, even a trusted partner?",
			//	"answerText": ["Yes.", "No."],
			//	"score": [0, 0],
			//	"weight": [1, 1]
			// },
			{ // Added by RAA
				"qid":"19892",
				"text":"Foot fetish?",
				"answerText": ["Yes, I have a foot fetish!", "No, I don't have a foot fetish"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{ // Added by RAA
				"qid":"18639",
				"text":"If your partner had a foot fetish, would you include it in your sex life?",
				"answerText": ["Yes, for their sake", "Yes, because I like it, too","No"],
				"score": [1, 1,-1],
				"weight": [1, 1,1]
			},
			{ // Added by RAA
				"qid":"26367",
				"text":"Is there at least one nude photo of you on the Net?",
				"answerText": ["Yes", "No","Yes, but my face isn't visible","Not sure"],
				"score": [1, 0,0.5,0],
				"weight": [1, 0,1,0]
			},
			{ // Added by RAA
				"qid":"36970",
				"text":"Would you be willing to dress up as a member of the opposite sex if it would turn your partner on?",
				"answerText": ["If it excites them, I'd even do it in public.", "Yes, but only in private.","No.","I do it already!"],
				"score": [1, 1,-1,1],
				"weight": [1, 1,1,1]
			},
			{ // Added by RAA
				"qid":"61278",
				"text":"How would you react if a partner bought you an outfit to be worn during sex?",
				"answerText": ["Positively.", "Negatively.","Indifferently.","It would depend upon the outfit."],
				"score": [1,-1,0,0],
				"weight": [1, 1,1,1]
			},
			{ // Added by RAA
				"qid":"50178",
				"text":"Do you enjoy it when someone uses refrigerated items or ice cubes on you during sex?",
				"answerText": ["Yes.", "No.","I don't know."],
				"score": [1, -1,0],
				"weight": [1, 1,1]
			},
			{ // Added by RAA
				"qid":"70508",
				"text":"Would you have sex with someone, if you were blindfolded and would never know who it was, only that it would be someone you had never met before?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.5]
			},
			{ // Added by RAA
				"qid":"1132",
				"text":"Would you ever consider cutting a partner (who asked for it) in sexual play?",
				"answerText": ["Yes", "No","Maybe"],
				"score": [1, -1,0.5],
				"weight": [1, 1,1]
			},
			{ // Added by RAA
				"qid":"20062",
				"text":"While in the middle of the best lovemaking of your life, if your lover asked you to squeal like a dolphin, would you?",
				"answerText": ["Absolutely.", "No way.","The best?  Maybe. . ."],
				"score": [1, -1,0],
				"weight": [1, 1,1]
			},
			{ // Added by RAA
				"qid":"37339",
				"text":"Someone you're very attracted to admits to having a tickling fetish. Would you let them tickle you?",
				"answerText": ["Yes! That turns me on/could turn me on!", "Maybe, I think I'd enjoy if limits are respected.","Only to please them - I don't think I'd like it.","No way!"],
				"score": [1,1,1,-1],
				"weight": [1, 1,1,1]
			},
			{ // Added by RAA
				"qid":"64334",
				"text":"Imagine that your partner does not enjoy performing oral sex and refuses to ever perform it on you. How disappointed would you be?",
				"answerText": ["Extremely disappointed.", "Somewhat disappointed.","Slightly disappointed.","Not at all disappointed."],
				"score": [1, 1,0,-1],
				"weight": [0.5, 0.5, 0.5, 0.5]
			}
		],

		"rough_kinky": [
			{
				"qid":"18530",
				"text":"Do you want your partner to be kinkier than you?",
				"answerText": ["Yes", "No", "Not possible"],
				"score": [1, -1, 1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"1028",
				"text":"Is your ideal sex rough or gentle?",
				"answerText": ["Rough", "Gentle", "I enjoy both equally", "I'm a virgin"],
				"score": [1, -1, 1, -1],
				"weight": [1, 0.5, 1, 1]
			},
			{
				"qid":"72086",
				"text":"If your partner needed lovemaking to always be gentle, would you be fine with this?",
				"answerText": ["Yes.", "No."],
				"score": [-1, 1],
				"weight": [1, 1]
			},
			{
				"qid":"9628",
				"text":"Biting?",
				"answerText": ["No", "Yes", "Let's break skin"],
				"score": [-1, 0.5, 1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"30115",
				"text":"Have you ever gotten, or would you ever get, a piercing below the belt?",
				"answerText": ["I have.", "I would.", "I wouldn't."],
				"score": [1, 1, -1],
				"weight": [1, 1, 0.4]
			},
			{
				"qid":"1133",
				"text":"Do you have rape fantasies?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [1, 0.2]
			},
			{
				"qid":"58812",
				"text":"Would you consider roleplaying out a rape fantasy with partner who asked you to?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.3]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			}
		],


		"BDSM": [
			{
				"qid":"20",
				"text":"BDSM: Without looking it up, do you know exactly what it stands for?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{//Added by RAA
				"qid":"18",
				"text":"Do you have experience being in a slave/master relationship?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			}
		],

		"masochistic": [
			{
				"qid":"30",
				"text":"Would you like to receive pain during sex?",
				"answerText": ["Yes, lots and lots", "Yes, some", "No"],
				"score": [1, 0.3, -1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"28545",
				"text":"When having sex, do you like to have your hair pulled?",
				"answerText": ["Yes, and hard!", "Yes, but gently.", "No way.", "Don't know / Not sure."],
				"score": [1, 0.3, -1, 0],
				"weight": [1, 1, 1, 0.5]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			}
		],

		"dominant": [
			{
				"qid":"61733",
				"text":"Would you be pleased if a partner expressed the desire to be sexually humiliated by you?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
				
			},
			{
				"qid":"463",
				"text":"In your ideal sexual encounter, do you take control, or do they?",
				"answerText": ["I take control", "They take control"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"83808",
				"text":"Would you ever consider a relationship where you would take on an exclusive sexual role as master or slave?",
				"answerText": ["Yes, as the master only.", "Yes, as the slave only.", "Yes, as the master or the slave.", "No."],
				"score": [1, -1, 1, -1],
				"weight": [1, 1, 0.7, 1]
			},
			{//Added by RAA
				"qid":"87450",
				"text":"How would you prefer your lover in bed?",
				"answerText": ["Very dominant", "Somewhat dominant", "Neutral or willing to take turns", "Submissive"],
				"score": [-1, -1,0,1],
				"weight": [1, .7, 0.7, 1]
			}
		],
		

		"submissive": [
			{
				"qid":"463",
				"text":"In your ideal sexual encounter, do you take control, or do they?",
				"answerText": ["I take control", "They take control"],
				"score": [-1, 1],
				"weight": [1, 1]
			},
			{
				"qid":"60726",
				"text":"If a trusted partner asked you to submit to them sexually, would you? Assume that this would involve letting them collar you, command you, and have control over you during sex.",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.5]
			},
			{
				"qid":"38320",
				"text":"Is it generally acceptable to you for a sex partner to initiate foreplay while you are sleeping?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"83808",
				"text":"Would you ever consider a relationship where you would take on an exclusive sexual role as master or slave?",
				"answerText": ["Yes, as the master only.", "Yes, as the slave only.", "Yes, as the master or the slave.", "No."],
				"score": [-1, 1, 1, -1],
				"weight": [1, 1, 0.7, 1]
			},
			{
				"qid":"79635",
				"text":"How would you feel if someone called you \"good girl\" or \"good boy\" during sex?",
				"answerText": ["Positive.", "Negative.", "Indifferent.", "It would depend on which of the two I was called."],
				"score": [1, -1, 0, 1],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid":"11",
				"text":"How does the idea of being slapped hard in the face during sex make you feel?",
				"answerText": ["Horrified", "Aroused", "Nostalgic", "Indifferent"],
				"score": [-1, 1, 1, 0],
				"weight": [1, 1, 0.7, 0.6]
			},
			{
				"qid":"84005",
				"text":"As an adult, have you ever worn a leash and collar in public?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.2]
			},
			{
				"qid":"48347",
				"text":"Do you think you could ever enjoy being humiliated as part of a sexual experience?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.6]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			},
			{//Added by RAA
				"qid":"87450",
				"text":"How would you prefer your lover in bed?",
				"answerText": ["Very dominant", "Somewhat dominant", "Neutral or willing to take turns", "Submissive"],
				"score": [1, 1,0,-1],
				"weight": [1, .7, 0.7, 1]
			}
		],



		"bondage": [
			{
				"qid":"29",
				"text":"Would you rather...",
				"answerText": ["be tied up during sex", "do the tying", "avoid bondage all together"],
				"score": [1, 1, -1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"1134",
				"text":"Do you have a desire (even if it's secret) to take part in sexual activities involving bondage?",
				"answerText": ["Yes", "No", "Absolutely not."],
				"score": [1, 0, -1],
				"weight": [1, 0.5, 1]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			},
			{
				"qid": "18",
				"text": "Do you have experience being in a slave/master relationship?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.7, 1]
			}
		],


		"anal": [
			{
				"qid":"1040",
				"text":"Receiving anal sex?",
				"answerText": ["I like it / I think I might like it", "I don't like it / I don't think I would like it"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"18600",
				"text":"People who like RECEIVING anal sex are...",
				"answerText": ["Exploring their sexuality to the full", "Perverts", "Beyond my comprehension"],
				"score": [1, -1, -1],
				"weight": [0.3, 1, 1]
			},
			{
				"qid":"64476",
				"text":"Under the right circumstances, would you allow a partner to lick your anus?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{ //Added by RAA
				"qid":"81254",
				"text":"Anal sex. Do you...",
				"answerText": ["Like to give", "Live to receive", "Like it both ways!","Hate it! / Never tried it"],
				"score": [1, 1, 1, 0],
				"weight": [1, 1, 1,1]
			},
			{ //Added by RAA
				"qid":"49345",
				"text":"Would you consider performing anilingus on a partner who asked you to?",
				"answerText": ["Yes.","No."],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{ //Added by RAA
				"qid":"64476",
				"text":"Under the right circumstances, would you allow a partner to lick your anus?",
				"answerText": ["Yes.","No."],
				"score": [1, -1],
				"weight": [1, 1]
			}
		],

		"shaven": [
			{
				"qid":"58829",
				"text":"When it comes to your pubic hair, do you make a regular effort to maintain its appearance (or lack thereof)?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{ //Added by RAA
				"qid":"134",
				"text":"Do you think women have an obligation to keep their legs shaved?",
				"answerText": ["Yes","No"],
				"score": [1,-1],
				"weight": [1,.5]
			},
			{ //Added by RAA
				"qid":"39714",
				"text":"Do you find the idea of shaving a partner's pubic hair exciting?",
				"answerText": ["Yes.","No."],
				"score": [1,-1],
				"weight": [1,1]
			},
			{ //Added by RAA
				"qid":"712",
				"text":"Do you think a girl with hairy underarms is necessarily unattractive?",
				"answerText": ["Yes","No"],
				"score": [1,-1],
				"weight": [1,0.5]
			},
			{ //Added by RAA
				"qid":"7079",
				"text":"Could you date someone with abnormal amounts of body hair?",
				"answerText": ["Yes","No","I don't know"],
				"score": [-1,1,0],
				"weight": [1,1,1]
			},
			{ //Added by RAA
				"qid":"1572",
				"text":"Would you shave something you usually don't because your boyfriend/girlfriend asked you to?",
				"answerText": ["Yes","No"],
				"score": [1,-1],
				"weight": [1,1]
			},
			{ //Added by RAA
				"qid":"83480",
				"text":"Which pubic hair style do you prefer for a partner?",
				"answerText": ["Natural.","Neatly trimmed.","Completely shaven.","It doesn't matter."],
				"score": [-1,0,1,0],
				"weight": [1,1,1,1]
			},
			{ //Added by RAA
				"qid":"32855",
				"text":"Underarms can be a hairy subject. How do you maintain your pits?",
				"answerText": ["I let it grow, wild & free!","Occasionally I'll trim.","I shave consistently.","Whatever I feel like at the time."],
				"score": [-1,-1,1,-1],
				"weight": [1,1,1,1]
			}
		],

		"unshaven": [
			{
				"qid":"58829",
				"text":"When it comes to your pubic hair, do you make a regular effort to maintain its appearance (or lack thereof)?",
				"answerText": ["Yes.", "No."],
				"score": [-1, 1],
				"weight": [0.5, 1]
			},
			{ //Added by RAA
				"qid":"134",
				"text":"Do you think women have an obligation to keep their legs shaved?",
				"answerText": ["Yes","No"],
				"score": [-1,1],
				"weight": [.5,1]
			},
			{ //Added by RAA
				"qid":"712",
				"text":"Do you think a girl with hairy underarms is necessarily unattractive?",
				"answerText": ["Yes","No"],
				"score": [-1,1],
				"weight": [.5,1]
			},
			{ //Added by RAA
				"qid":"7079",
				"text":"Could you date someone with abnormal amounts of body hair?",
				"answerText": ["Yes","No","I don't know"],
				"score": [1,-1,0],
				"weight": [1,1,1]
			},
			{ //Added by RAA
				"qid":"83480",
				"text":"Which pubic hair style do you prefer for a partner?",
				"answerText": ["Natural.","Neatly trimmed.","Completely shaven.","It doesn't matter."],
				"score": [1,0,-1,0],
				"weight": [1,1,1,1]
			},
			{ //Added by RAA
				"qid":"32855",
				"text":"Underarms can be a hairy subject. How do you maintain your pits?",
				"answerText": ["I let it grow, wild & free!","Occasionally I'll trim.","I shave consistently.","Whatever I feel like at the time."],
				"score": [1,0,-1,0],
				"weight": [1,1,1,1]
			}
		]

	};
