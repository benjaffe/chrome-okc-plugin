// // This method is used, so that the match patterns can be specified in the
// //  manifest file.
// chrome.extension.sendRequest('INJECT_GA');  // Trigger the background script