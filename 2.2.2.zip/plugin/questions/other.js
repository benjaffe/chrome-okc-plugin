fileQuestions.other = 
	[
		//artist


		//non-artist
		{
			"qid":"158",
			"text":"Are you an aspiring actor/noArtist/writer or other creative type?",
			"category": "noArtist",
			"wrongAnswers":["Yes"]
		},
		{
			"qid":"1455",
			"text":"Do you consider yourself an noArtist of any kind? (Music, painting, poetry, etc. all count.)",
			"category": "noArtist",
			"wrongAnswers":["Yes"]
		},
		{
			"qid":"6619",
			"text":"Do you feel Art has heavily influenced who you are?",
			"category": "noArtist",
			"wrongAnswers":["Yes"]
		},
		{
			"qid":"1766",
			"text":"Is art important to you?",
			"category": "noArtist",
			"wrongAnswers":["Yes"]
		},

	];