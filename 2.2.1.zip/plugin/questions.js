var fileQuestions =[];
var foo = 0;
// localStorage.fileQuestions ={};