fileQuestions.sex =
	[
		//cuddling
		{
			"qid":"48753",
			"text":"Do you like to cuddle?",
			"category": "cuddling",
			"wrongAnswers":["No.","Sometimes - It depends."]
		},
		// {
		// 	"qid":"19378",
		// 	"text":"How are you most likely to show your partner you care?",
		// 	"category": "cuddling",
		// 	"wrongAnswers":["Gifts: Buy them flowers, jewelery or a new gadget","Actions: Do something nice (like a date or errand)","Words: Tell them how much you appreciate them"]
		// },
		{
			"qid":"72318",
			"text":"Would you consider inviting someone to bed with you for clearly-stated non-sexual purposes (e.g., cuddle and sleep only) on a first date?",
			"category": "cuddling",
			"wrongAnswers":["No."]
		},
		{
			"qid":"41850",
			"text":"How important is it for you to make physical contact when showing affection for someone?",
			"category": "cuddling",
			"wrongAnswers":["Not important.","Somewhat important."]
		},

		//love priority
		{
			"qid":"35",
			"text":"Regardless of future plans, what's more interesting to you right now?",
			"category": "love",
			"wrongAnswers":["Sex"]
		},
		{
			"qid":"14913",
			"text":"Did you join OkCupid just so you could find people to have sex with?",
			"category": "love",
			"wrongAnswers":["Yes"]
		},
		{
			"qid":"41953",
			"text":"About how long do you want your next relationship to last?",
			"category": "love",
			"wrongAnswers":["One night","A few months to a year"]
		},
		{
			"qid":"20135",
			"text":"How do you feel about falling in love?",
			"category": "love",
			"wrongAnswers":["I try to avoid it","I'm indifferent / not sure"]
		},

		//fetish
		{
			"qid":"67511",
			"text":"Suppose you\'re dating someone who seems to have long-term potential. You discover that they want to urinate on you during sex. Would you consider staying with this person?",
			"category": "fetish",
			"wrongAnswers":["No."]
		},
		{
			"qid":"665",
			"text":"Are you fetish-friendly?",
			"category": "fetish",
			"wrongAnswers":["Ew!"]
		},

		//kinky
		{
			"qid":"18530",
			"text":"Do you want your partner to be kinkier than you?",
			"category": "kinky",
			"wrongAnswers":["No"]
		},
		{
			"qid":"1028",
			"text":"Is your ideal sex rough or gentle?",
			"category": "kinky",
			"wrongAnswers":["Gentle","I'm a virgin"]
		},
		{
			"qid":"72086",
			"text":"If your partner needed lovemaking to always be gentle, would you be fine with this?",
			"category": "kinky",
			"wrongAnswers":["Yes."]
		},
		{
			"qid":"9628",
			"text":"Biting?",
			"category": "kinky",
			"wrongAnswers":["No"]
		},
		{
			"qid":"1133",
			"text":"Do you have rape fantasies?",
			"category": "kinky",
			"wrongAnswers":["No"]
		},
		{
			"qid":"30115",
			"text":"Have you ever gotten, or would you ever get, a piercing below the belt?",
			"category": "kinky",
			"wrongAnswers":["I wouldn't."]
		},
		{
			"qid":"58812",
			"text":"Would you consider roleplaying out a rape fantasy with partner who asked you to?",
			"category": "kinky",
			"wrongAnswers":["No."]
		},


		//BDSM
		{
			"qid":"20",
			"text":"BDSM: Without looking it up, do you know exactly what it stands for?",
			"category": "BDSM",
			"wrongAnswers":["No"]
		},
		{
			"qid":"1011",
			"text":"Do you know what a 'safeword' is, in a sexual context?",
			"category": "BDSM",
			"wrongAnswers":["No."]
		},



		//masochistic
		{
			"qid":"30",
			"text":"Would you like to receive pain during sex?",
			"category": "masochistic",
			"wrongAnswers":["No"]
		},
		{
			"qid":"28545",
			"text":"When having sex, do you like to have your hair pulled?",
			"category": "masochistic",
			"wrongAnswers":["No way.","Don't know / Not sure."]
		},

		//dominant
		{
			"qid":"61733",
			"text":"Would you be pleased if a partner expressed the desire to be sexually humiliated by you?",
			"category": "dominant",
			"wrongAnswers":["No."]
			
		},


		//submissive
		{
			"qid":"463",
			"text":"In your ideal sexual encounter, do you take control, or do they?",
			"category": "submissive",
			"wrongAnswers":["I take control"]
		},
		{
			"qid":"60726",
			"text":"If a trusted partner asked you to submit to them sexually, would you? Assume that this would involve letting them collar you, command you, and have control over you during sex.",
			"category": "submissive",
			"wrongAnswers":["No."]
		},
		{
			"qid":"38320",
			"text":"Is it generally acceptable to you for a sex partner to initiate foreplay while you are sleeping?",
			"category": "submissive",
			"wrongAnswers":["No."]
		},
		{
			"qid":"83808",
			"text":"Would you ever consider a relationship where you would take on an exclusive sexual role as master or slave?",
			"category": "submissive",
			"wrongAnswers":["No","Yes, as the master only."]
		},
		{
			"qid":"79635",
			"text":"How would you feel if someone called you \"good girl\" or \"good boy\" during sex?",
			"category": "submissive",
			"wrongAnswers":["Negative.","Indifferent."]
		},
		{
			"qid":"11",
			"text":"How does the idea of being slapped hard in the face during sex make you feel?",
			"category": "submissive",
			"wrongAnswers":["Horrified","Indifferent"]
		},
		{
			"qid":"84005",
			"text":"As an adult, have you ever worn a leash and collar in public?",
			"category": "submissive",
			"wrongAnswers":["No."]
		},
		{
			"qid":"48347",
			"text":"Do you think you could ever enjoy being humiliated as part of a sexual experience?",
			"category": "submissive",
			"wrongAnswers":["No."]
		},



		//bondage
		{
			"qid":"29",
			"text":"Would you rather...",
			"category": "bondage",
			"wrongAnswers":["avoid bondage all together","do the tying"]
		},
		{
			"qid":"1134",
			"text":"Do you have a desire (even if it's secret) to take part in sexual activities involving bondage?",
			"category": "bondage",
			"wrongAnswers":["No","Absolutely not."]
		},


		//anal
		{
			"qid":"1040",
			"text":"Receiving anal sex?",
			"category": "anal",
			"wrongAnswers":["I don't like it / I don't think I would like it"]
		},
		{
			"qid":"18600",
			"text":"People who like RECEIVING anal sex are...",
			"category": "anal",
			"wrongAnswers":["Perverts","Beyond my comprehension"]
		},
		{
			"qid":"64476",
			"text":"Under the right circumstances, would you allow a partner to lick your anus?",
			"category": "anal",
			"wrongAnswers":["No."]
		},

		//shaved
		{
			"qid":"58829",
			"text":"When it comes to your pubic hair, do you make a regular effort to maintain its appearance (or lack thereof)?",
			"category": "shaved",
			"wrongAnswers":["No."]
		},

	];