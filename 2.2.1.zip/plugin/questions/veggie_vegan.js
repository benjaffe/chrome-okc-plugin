//question search words: vegetarian, vegan
fileQuestions.veg =
	[
		//veg
		{
			"qid":"179268",
			"text":"Are you either vegetarian or vegan?",
			"category": "veg",
			"wrongAnswers":["Yes"]
		},
		{
			"qid":"22198",
			"text":"If you were out to dinner and your date was a vegetarian would you still order meat?",
			"category": "veg",
			"wrongAnswers":["I'm vegetarian too"]
		},
		{
			"qid":"36345",
			"text":"If an otherwise perfect match gave you an ultimatum to become a vegetarian, what would you do?",
			"category": "veg",
			"wrongAnswers":["Smile - I'm already a vegetarian."]		//"Comply - Become a vegetarian."
		}

		//not veg
	];