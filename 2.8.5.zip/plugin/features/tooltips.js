_OKCP.initTooltips = function(){
    // var lastDisplayedMessageIndex =
    var messages = [{

    }];
};