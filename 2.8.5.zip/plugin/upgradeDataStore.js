
// check to see if any database upgrades or localStorage cleanups are necessary
(function () {
    // create a settings object if there isn't one
    if (!localStorage.okcpSettings) {
        localStorage.okcpSettings = JSON.stringify({});
    }

    // create a database if there isn't one
    if (localStorage.okcp === undefined) {
        localStorage.okcp = JSON.stringify({
            dataModelVersion: '1.1.40',
            profileList: {},
            settings: {}
        });
    }

    var storage = JSON.parse(localStorage.okcp);
    storage.dataCleanupJobNumToReach = '2.3.0';

    // run data cleanup if needed
    if (storage.dataCleanupJobNum === storage.dataCleanupJobNumToReach) {
        dataCleanup();
    }

    function dataCleanup() {
        var upgradeMessage = ['Data Cleanup Run:'];

        // confirm that proper keys exist
        storage.settings = storage.settings || {};
        storage.profileList = storage.profileList || {};
        storage.questionCategories = storage.questionCategories || ["not_volatile","generally_happy","non-monogamous","communicative","not_possessive","cuddling","sex-positive"];

        // if backup isn't current, create a backup
        if (localStorage.okcpBackup_2_2_2 === undefined) {
            localStorage.okcpBackup_2_2_2 = localStorage.okcp;
            upgradeMessage.push('  * Created a database backup (version 2.2.2)');

            //upgrade them to the new default category names
            storage.questionCategories = ["not_volatile","generally_happy","non-monogamous","communicative","not_possessive","cuddling","sex-positive"];
        }

        // clean up deprecated keys
        var deprecatedKeys = ['okcpSettings','okcp_b130110','okcp_b130124'];
        for (var i = 0; i < deprecatedKeys.length; i++) {
            if (!!localStorage[deprecatedKeys[i]]) {
                localStorage.removeItem(deprecatedKeys[i]);
                upgradeMessage.push('  * Removed deprecated key ('+deprecatedKeys[i]+')');
            }
        }

        // upgrade data model from 1.x if needed
        if (storage.hiddenProfileList !== undefined) {
            var oldData = storage;
            var newData = {
                'dataModelVersion': '1.1.0',
                'profileList': {}
            };
            for (i=0; i < oldData.hiddenProfileList.length; i++) {
                newData.profileList[oldData.hiddenProfileList[i]] = {h:true};
            }
            localStorage.okcp = JSON.stringify(newData);
            upgradeMessage.push('  * Updated Data Model to Version 1.1.0');
        }

        storage.dataCleanupJobNum = storage.dataCleanupJobNumToReach;
        localStorage.okcp = JSON.stringify(storage);
    }

    //move settings to okcpSettings if necessary
    if (!_OKCP.settings('questionCategories')) {
        console.log('hi');
        _OKCP.settings('questionCategories', _OKCP.storage('questionCategories'));
        upgradeMessage.push('Moved questionCategories to settings data store.');
    }


    console.log(upgradeMessage.join('\n'));


})();