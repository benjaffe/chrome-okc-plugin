// this file gets information about the current page and state
// at least it will when I finish it

// if () {
// 	$('#messages li .subject').map(function(){
// 	  return $(this).text();
// 	}).get()
// }