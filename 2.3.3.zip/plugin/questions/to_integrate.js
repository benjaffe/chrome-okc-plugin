[

//children is a difficult topic, since some questions refer to whether people have or like children, and some refer to whether they want them, and others are ambiguous
{
	"qid":"105",
	"text":"Do you have a child or children?",
	"category": "children",
	"wrongAnswers":["Yes"]
},
{
	"qid":"979",
	"text":"How many children would you ideally like to have?",
	"category": "children",
	"wrongAnswers":["None"]
},
{
	"qid":"63010",
	"text":"Do you have names planned out for future children?",
	"category": "children",
	"wrongAnswers":["No, and I'm not planning on any future children."]
},
{
	"qid":"80041",
	"text":"Are you looking for a partner to have children with?",
	"category": "children",
	"wrongAnswers":["No"]
},
{
	"qid":"15698",
	"text":"How do you feel about kids?",
	"category": "children",
	"wrongAnswers":["God, how revolting. *shudder*","They're okay, but keep the unruly ones at bay.","I'm indifferent."]
}

]