$(function(){
	
	_OKCP.getAnswers();

});