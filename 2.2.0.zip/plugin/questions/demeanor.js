fileQuestions.demeanor = 
	[
		//unaggressive
		{
			"qid":"55349",
			"text":"Have you ever thrown an object in anger during an argument?",
			"category": "unaggressive",
			"wrongAnswers":["Yes."]
		},
		{
			"qid":"386",
			"text":"If someone intentionally damaged your property, would you be more likely to call the police, or to fight them?",
			"category": "unaggressive",
			"wrongAnswers":["Fight them"]
		},
		{
			"qid":"6689",
			"text":"Are you quietly angry a lot of the time?",
			"category": "unaggressive",
			"wrongAnswers":["Yes"]
		}


		//generally happy


	];