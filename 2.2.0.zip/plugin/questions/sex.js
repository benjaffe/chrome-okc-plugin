fileQuestions.sex =
	[
		//cuddling


		//love priority


		//fetish
		{
			"qid":"67511",
			"text":"Suppose you\'re dating someone who seems to have long-term potential. You discover that they want to urinate on you during sex. Would you consider staying with this person?",
			"category": "fetish",
			"wrongAnswers":["No."]
		},
		{
			"qid":"665",
			"text":"Are you fetish-friendly?",
			"category": "fetish",
			"wrongAnswers":["Ew!"]
		},

		//kinky


		//BDSM


		//masochistic


		//dominant


		//submissive


		//bondage


		//anal


		//shaved


	];