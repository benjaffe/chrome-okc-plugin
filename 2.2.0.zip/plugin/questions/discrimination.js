fileQuestions.discrimination =
	[
		//race


		//women


		//mental health


		//disability


		//weight

		
	];