fileQuestions.other = 
	[
		//artist


		//non-artist


	];